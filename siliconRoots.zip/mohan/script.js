window.addEventListener('load', function () {
    setTimeout(() => {
        document.getElementById('loading-overlay').style.display = 'none';
    }, 3000); 
});
